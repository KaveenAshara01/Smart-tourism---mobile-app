// services/itineraryService.ts
import axios from 'axios';
import {
    collection, addDoc, getDocs, doc, getDoc, deleteDoc,
    query, where, orderBy, Timestamp
} from 'firebase/firestore';
import { db } from '../config/firebase';
import { API_BASE_URL, API_ENDPOINTS } from '../constants/API';
import { ItineraryRequest, Itinerary } from '../types';

const api = axios.create({
    baseURL: API_BASE_URL,
    timeout: 60000,
    headers: { 'Content-Type': 'application/json' },
});

export const itineraryService = {

    generateItinerary: async (request: ItineraryRequest): Promise<Itinerary> => {
        const response = await api.post(API_ENDPOINTS.GENERATE_ITINERARY, request);
        const data = response.data;

        const itinerary: Itinerary = {
            id: data.id,
            userId: request.userId,
            createdAt: new Date(),
            preferences: request,
            days: data.days,
            statistics: data.statistics,
        };

        const docRef = await addDoc(collection(db, 'itineraries'), {
            ...itinerary,
            createdAt: Timestamp.fromDate(itinerary.createdAt),
        });

        itinerary.id = docRef.id;
        return itinerary;
    },

    getItinerary: async (itineraryId: string): Promise<Itinerary | null> => {
        const snap = await getDoc(doc(db, 'itineraries', itineraryId));
        if (!snap.exists()) return null;
        const d = snap.data();
        return {
            ...d,
            id: snap.id,
            createdAt: d.createdAt?.toDate?.() ?? new Date(d.createdAt),
        } as Itinerary;
    },

    getUserItineraries: async (userId: string): Promise<Itinerary[]> => {
        const q = query(
            collection(db, 'itineraries'),
            where('userId', '==', userId),
            orderBy('createdAt', 'desc')
        );
        const snap = await getDocs(q);
        return snap.docs.map(d => ({
            ...d.data(),
            id: d.id,
            createdAt: d.data().createdAt?.toDate?.() ?? new Date(d.data().createdAt),
        })) as Itinerary[];
    },

    deleteItinerary: async (itineraryId: string): Promise<void> => {
        await deleteDoc(doc(db, 'itineraries', itineraryId));
    },

    trackBehavior: async (behaviorData: object): Promise<void> => {
        try {
            await api.post(API_ENDPOINTS.TRACK_BEHAVIOR, behaviorData);
        } catch {
            // non-critical, swallow
        }
    },
};

export const forecastService = {
    getForecast: async (scenario?: object): Promise<ForecastResult> => {
        const response = await api.post(API_ENDPOINTS.FORECAST, { scenario: scenario ?? {} });
        return response.data as ForecastResult;
    },

    getDistrictForecast: async (district: string, month: string): Promise<DistrictForecast> => {
        const response = await api.get(`${API_ENDPOINTS.GET_FORECAST_DISTRICT}/${district}/${month}`);
        return response.data as DistrictForecast;
    },
};

export const sentimentService = {
    analyzeTexts: async (texts: string[]): Promise<SentimentResult> => {
        const response = await api.post(API_ENDPOINTS.SENTIMENT, { texts });
        return response.data as SentimentResult;
    },

    getAttractionSentiment: async (attractionId: number): Promise<AttractionSentiment> => {
        const response = await api.get(`${API_ENDPOINTS.SENTIMENT}/${attractionId}`);
        return response.data as AttractionSentiment;
    },
};

export interface ForecastResult {
    prediction_month: string;
    country_level: {
        estimated_unique_tourists: number;
        total_district_visits: number;
    };
    district_level: Record<string, {
        predicted_visitors: number;
        visit_probability_pct: number;
        market_share_pct: number;
    }>;
    model_metadata: { mape: number; r2: number };
}

export interface DistrictForecast {
    district: string;
    month: string;
    predicted_visitors: number;
    visit_probability_pct: number;
    market_share_pct: number;
    country_level: { estimated_unique_tourists: number; total_district_visits: number };
}

export interface SentimentResult {
    results: Array<{ text: string; score: number; score_100: number; label: 'Positive' | 'Neutral' | 'Negative' }>;
    aggregate: { avg_score: number; avg_score_100: number; label: string; count: number };
}

export interface AttractionSentiment {
    attractionId: number;
    sentimentScore: number;
    label: string;
}
