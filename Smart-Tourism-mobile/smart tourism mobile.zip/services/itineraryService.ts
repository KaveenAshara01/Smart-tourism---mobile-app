// services/itineraryService.ts
import axios from 'axios';
import {
    collection, addDoc, getDocs, doc, getDoc, deleteDoc,
    query, where, orderBy, Timestamp
} from 'firebase/firestore';
import { db } from '../config/firebase';
import { API_BASE_URL, API_ENDPOINTS } from '../constants/API';
import { ItineraryRequest, Itinerary } from '../types';

const api = axios.create({
    baseURL: API_BASE_URL,
    timeout: 60000,
    headers: { 'Content-Type': 'application/json' },
});

// ─── Itinerary Service ───────────────────────────────────────────────────────

export const itineraryService = {

    generateItinerary: async (request: ItineraryRequest): Promise<Itinerary> => {
        const response = await api.post(API_ENDPOINTS.GENERATE_ITINERARY, request);
        const data = response.data;

        const itinerary: Itinerary = {
            id: data.id,
            userId: request.userId,
            createdAt: new Date(),
            preferences: request,
            days: data.days,
            statistics: data.statistics,
        };

        const docRef = await addDoc(collection(db, 'itineraries'), {
            ...itinerary,
            createdAt: Timestamp.fromDate(itinerary.createdAt),
        });

        itinerary.id = docRef.id;
        return itinerary;
    },

    getItinerary: async (itineraryId: string): Promise<Itinerary | null> => {
        const snap = await getDoc(doc(db, 'itineraries', itineraryId));
        if (!snap.exists()) return null;
        const d = snap.data();
        return {
            ...d,
            id: snap.id,
            createdAt: d.createdAt?.toDate?.() ?? new Date(d.createdAt),
        } as Itinerary;
    },

    getUserItineraries: async (userId: string): Promise<Itinerary[]> => {
        const q = query(
            collection(db, 'itineraries'),
            where('userId', '==', userId),
            orderBy('createdAt', 'desc')
        );
        const snap = await getDocs(q);
        return snap.docs.map(d => ({
            ...d.data(),
            id: d.id,
            createdAt: d.data().createdAt?.toDate?.() ?? new Date(d.data().createdAt),
        })) as Itinerary[];
    },

    deleteItinerary: async (itineraryId: string): Promise<void> => {
        await deleteDoc(doc(db, 'itineraries', itineraryId));
    },

    trackBehavior: async (behaviorData: object): Promise<void> => {
        try {
            await api.post(API_ENDPOINTS.TRACK_BEHAVIOR, behaviorData);
        } catch {
            // non-critical
        }
    },
};

// ─── Forecast Service (Component 1) ─────────────────────────────────────────

export interface ForecastResult {
    prediction_month: string;
    country_level: {
        estimated_unique_tourists: number;
        total_district_visits: number;
    };
    district_level: Record<string, {
        predicted_visitors: number;
        visit_probability_pct: number;
        market_share_pct: number;
    }>;
    model_metadata: { mape: number; r2: number };
}

export interface DistrictForecast {
    district: string;
    month: string;
    predicted_visitors: number;
    visit_probability_pct: number;
    market_share_pct: number;
    country_level: { estimated_unique_tourists: number; total_district_visits: number };
}

export const forecastService = {
    getForecast: async (scenario?: object): Promise<ForecastResult> => {
        const response = await api.post(API_ENDPOINTS.FORECAST, { scenario: scenario ?? {} });
        return response.data as ForecastResult;
    },

    getDistrictForecast: async (district: string, month: string): Promise<DistrictForecast> => {
        const response = await api.get(`${API_ENDPOINTS.GET_FORECAST_DISTRICT}/${district}/${month}`);
        return response.data as DistrictForecast;
    },
};

// ─── Sentiment Service (Component 2) ────────────────────────────────────────

export interface SentimentResult {
    results: Array<{
        text: string;
        score: number;
        score_100: number;
        label: 'Positive' | 'Neutral' | 'Negative';
    }>;
    aggregate: { avg_score: number; avg_score_100: number; label: string; count: number };
}

export interface AttractionSentiment {
    attractionId: number;
    sentimentScore: number;
    label: string;
}

export interface DistrictSentiment {
    district: string;
    sentiment_score: number;
    sentiment_label: string;
    sample_count: number;
}

export const sentimentService = {
    analyzeTexts: async (texts: string[]): Promise<SentimentResult> => {
        const response = await api.post(API_ENDPOINTS.SENTIMENT, { texts });
        return response.data as SentimentResult;
    },

    getAttractionSentiment: async (attractionId: number): Promise<AttractionSentiment> => {
        const response = await api.get(`${API_ENDPOINTS.GET_SENTIMENT}/${attractionId}`);
        return response.data as AttractionSentiment;
    },

    getDistrictSentiment: async (district: string): Promise<DistrictSentiment> => {
        const response = await api.get(`${API_ENDPOINTS.GET_SENTIMENT}/district/${district}`);
        return response.data as DistrictSentiment;
    },

    getAllDistrictSentiments: async (): Promise<Record<string, DistrictSentiment>> => {
        const response = await api.get(`${API_ENDPOINTS.GET_SENTIMENT}/districts`);
        return response.data as Record<string, DistrictSentiment>;
    },
};

// ─── Weather Service (Open-Meteo via Flask proxy) ────────────────────────────

export interface DistrictWeather {
    district: string;
    temperature: number;
    condition: string;
    humidity: number;
    windspeed: number;
    rainfall_mm: number;
}

export const weatherService = {
    getAllDistrictWeather: async (): Promise<Record<string, DistrictWeather>> => {
        const response = await api.get(API_ENDPOINTS.GET_WEATHER);
        return response.data as Record<string, DistrictWeather>;
    },
};

// ─── Monitoring Service (Component 3) ────────────────────────────────────────

export interface MonitoringStatus {
    model_version: string;
    last_run: string;
    drift_detected: boolean;
    severity: string;
    avg_mape: number;
    xgboost_weight: number;
    lstm_weight: number;
    action_taken: string;
}

export const monitoringService = {
    getStatus: async (): Promise<MonitoringStatus | null> => {
        try {
            const response = await api.get(API_ENDPOINTS.GET_MONITORING);
            return response.data as MonitoringStatus;
        } catch {
            return null;
        }
    },
};

// ─── Simulator Service (calls Flask → Component 1 for what-if) ───────────────

export interface SimulateRequest {
    district: string;
    month: number;
    temperature: number;
    rainfall: number;
    humidity: number;
    terror_score: number;
    economic_score: number;
    unrest_score: number;
    disaster_score: number;
    disease_score: number;
    crime_score: number;
    diplomacy_score: number;
}

export interface SimulateResult {
    district: string;
    month: number;
    predicted_visitors: number;
    baseline_visitors: number;
    change_percent: number;
    country_total: number;
    confidence: number;
}

export const simulatorService = {
    simulate: async (params: SimulateRequest): Promise<SimulateResult> => {
        const response = await api.post(API_ENDPOINTS.SIMULATE, params);
        return response.data as SimulateResult;
    },
};